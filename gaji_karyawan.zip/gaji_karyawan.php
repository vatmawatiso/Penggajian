<?php 
  // Menginisialisasi variabel dengan nilai default kosong
  $nm_karyawan = "";
  $nm_bagian = "";
  $nm_produk = "";
  $hasil = ""; // Pastikan ini juga didefinisikan
  $data = ['Harga' => ""]; // Inisialisasi array dengan nilai default

  include "koneksi.php";

  if (isset($_POST['hasil'])) {
      // Logika untuk mengambil dan menampilkan data...
      $nmKaryawan = $_POST["karyawan"] ?? ""; // Null coalescing operator untuk PHP 7+
      $nmProduk = $_POST["produk"] ?? "";
      $nmBagian = $_POST["bagian"] ?? "";
      $bil1 = $_POST['bil1'] ?? 0;
      $bil2 = $_POST['bil2'] ?? 0;
      $operasi = $_POST['operasi'] ?? '';

      // Simpan ke variabel lain jika perlu
      $nm_karyawan = $nmKaryawan;
      $nm_produk = $nmProduk;
      $nm_bagian = $nmBagian;

      // Query untuk mengambil data...
      $sql = "SELECT 
                p.nama_produk AS Produk,
                b.nama_bagian AS Bagian,
                h.harga AS Harga
              FROM 
                harga h
              JOIN 
                produk p ON h.id_produk = p.id_produk
              JOIN 
                bagian b ON h.id_bagian = b.id_bagian
              WHERE
                (p.nama_produk = '$nm_produk' AND b.nama_bagian = '$nm_bagian')";
              
      echo $sql;
      $query = mysqli_query($koneksi, $sql);
      
      if ($query) {
          $data = mysqli_fetch_array($query) ?: ['Harga' => ""]; // Tambahkan pemeriksaan apakah query berhasil dan data ada
          echo $data["Harga"];
      }

        // Proses perhitungan
        $bil1 = $_POST['bil1'] ?? 0;
        $bil2 = $_POST['bil2'] ?? 0;
        $operasi = $_POST['operasi'] ?? '';
        
        switch ($operasi) {
            case 'tambah':
                $hasil = $bil1 + $bil2; 
                $hasil_rupiah = "Rp " . number_format($hasil, 0, ',', '.');
                break;
            case 'kurang':
                $hasil = $bil1 - $bil2;
                $hasil_rupiah = "Rp " . number_format($hasil, 0, ',', '.');
                break;
            case 'kali':
                $hasil = $bil1 * $bil2;
                $hasil_rupiah = "Rp " . number_format($hasil, 0, ',', '.');
                break;
            case 'bagi':
                $hasil = $bil1 / $bil2;
                $hasil_rupiah = "Rp " . number_format($hasil, 0, ',', '.');
                break;
        }
      
  }
?>




<!-- Kemudian lanjutkan dengan kode HTML Anda seperti biasa... -->

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Tables / Data - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">NiceAdmin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">K. Anderson</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Kevin Anderson</h6>
              <span>Web Designer</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">
      <ul class="sidebar-nav" id="sidebar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <!-- End Dashboard Nav -->

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#"> <i class="bi bi-menu-button-wide"></i><span>Data Karyawan</span><i class="bi bi-chevron-down ms-auto"></i> </a>
          <ul id="components-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
            <li>
              <a href="karyawan_baru.php"> <i class="bi bi-circle"></i><span>Data Karyawan Baru</span> </a>
            </li>
            <li>
              <a href="karyawan_lama.php"> <i class="bi bi-circle"></i><span>Data Karyawa Lama</span> </a>
            </li>
          </ul>
        </li>
        <!-- End Components Nav -->

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#tables-nav" data-bs-toggle="collapse" href="#"> <i class="bi bi-layout-text-window-reverse"></i><span>Data Konsumen</span><i class="bi bi-chevron-down ms-auto"></i> </a>
          <ul id="tables-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
            <li>
              <a href="data_konsumenBaru.php"> <i class="bi bi-circle"></i><span>Data Konsumen Baru</span> </a>
            </li>
            <li>
              <a href="data_konsumenLama.php"> <i class="bi bi-circle"></i><span>Data Konsumen Lama</span> </a>
            </li>
          </ul>
        </li>
        <!-- End Tables Nav -->

        <li class="nav-heading">Perhitungan Gaji Karyawan</li>

        <li class="nav-item">
          <a class="nav-link collapsed" href="gaji_karyawan.php">
            <i class="bi bi-person"></i>
            <span>Gaji Karyawan</span>
          </a>
        </li>
        <!-- End Profile Page Nav -->
      </ul>
    </aside>
    <!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Data Tables</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item">Tables</li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">SLIP GAJI KARYAWAN</h5>

              <!-- General Form Elements -->
              <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Pilih Karyawan</label>
                  <div class="col-sm-10">
                    <select name="karyawan" class="form-select" aria-label="Default select example">
                      <option selected>Masukkan nama karyawan</option>
                      <?php 
                        include "koneksi.php";
                        $sql = mysqli_query($koneksi,"select * from karyawan") or die (mysqli_error($koneksi));
                        while ($data=mysqli_fetch_array($sql)) {
                      ?>
                        <option value="<?=$data['nama_karyawan']?>"><?=$data['nama_karyawan']?></option> 
                      <?php
                        }
                      ?>
                    </select>
                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Pilih Bagian</label>
                  <div class="col-sm-10">
                    <select name="bagian" class="form-select" aria-label="Default select example">
                      <option selected>Masukkan bagian</option>
                      <?php 
                        include "koneksi.php";
                        $sql = mysqli_query($koneksi,"select * from bagian") or die (mysqli_error($koneksi));
                        while ($data=mysqli_fetch_array($sql)) {
                      ?>
                        <option value="<?=$data['nama_bagian']?>"><?=$data['nama_bagian']?></option> 
                      <?php
                         }
                      ?>
                    </select>
                  </div>
                </div>

                <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Pilih Produk</label>
                  <div class="col-sm-10">
                    <select name="produk" class="form-select" aria-label="Default select example">
                      <option selected>Masukkan produk</option>
                      <?php 
                        include "koneksi.php";
                        $sql = mysqli_query($koneksi,"select * from produk") or die (mysqli_error($koneksi));
                        while ($data=mysqli_fetch_array($sql)) {
                      ?>
                        <option value="<?=$data['nama_produk']?>"><?=$data['nama_produk']?></option> 
                      <?php
                        }
                      ?>
                    </select>
                  </div>
                </div>

                <div class="row mb-3">
                    <label for="inputText" class="col-sm-8 col-form-label"></label>
                    <div class="col-sm-4">
                      <input type="number" name="bil2" class="form-control" placeholder="Masukkan jumlah yang dikerjakan">
                    </div>
                </div>

                <div class="row mb-3">
                    <label class="col-sm-8 col-form-label"></label>
                    <div class="col-sm-4">
                      <select class="form-select" aria-label="Default select example" name="operasi">
                        <option selected>Masukan operator perhitungan</option>
                        <option value="tambah">+</option>
                        <option value="kurang">-</option>
                        <option value="kali">x</option>
                        <option value="bagi">/</option>
                      </select>
                    </div>
                </div>

                <div class="row mb-3">
                  <label for="inputText" class="col-sm-8 col-form-label"></label>
                  <div class="col-sm-4">
                    <button type="submit" name="hasil" class="btn btn-primary">Simpan</button>
                    <button type="submit" class="btn btn-success"><i class="bi bi-printer-fill"></i> Cetak</button>
                  </div>
                </div>

              
              <!-- Table with stripped rows -->
              <table class="table datatable">
                  <?php 
                    // Query untuk mengambil data...
                    $sql = "SELECT 
                              p.nama_produk AS Produk,
                              b.nama_bagian AS Bagian,
                              h.harga AS Harga
                            FROM 
                              harga h
                            JOIN 
                              produk p ON h.id_produk = p.id_produk
                            JOIN 
                              bagian b ON h.id_bagian = b.id_bagian
                            WHERE
                              (p.nama_produk = '$nm_produk' AND b.nama_bagian = '$nm_bagian')";
                            
                    $query = mysqli_query($koneksi, $sql);
                    
                    if ($query) {
                        $data = mysqli_fetch_array($query) ?: ['Harga' => ""]; // Tambahkan pemeriksaan apakah query berhasil dan data ada
                        // Misalkan $harga adalah nilai yang ingin Anda tampilkan dalam format Rupiah
                        $harga = $data["Harga"]; // Contoh nilai harga

                        // Ubah nilai menjadi format Rupiah
                        $harga_rupiah = "Rp " . number_format($harga, 0, ',', '.');

                        // Tampilkan nilai dalam format Rupiah
                        // echo $harga_rupiah;

                    }
                  ?>
                <thead>
                  <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Karyawan</th>
                    <th scope="col">Nama Bagian</th>
                    <th scope="col">Jenis Produk</th>
                    <th scope="col">Harga</th>
                    <th scope="col">Sub Total</th>
                    <th scope="col">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">1</th>
                      <!-- NAMA KARYAWAN -->
                      <?php 
                        if ($nm_karyawan == "") {
                      ?>
                          <td></td>
                      <?php
                        }else{
                      ?>
                          <td><?= $nm_karyawan; ?></td>
                      <?php
                        }
                      ?>

                      <!-- NAMA BAGIAN -->
                      <?php 
                        if ($nm_bagian == "") {
                      ?>
                          <td></td>
                      <?php
                        }else{
                      ?>
                          <td><?= $nm_bagian; ?></td>
                      <?php
                        }
                      ?>

                      <!-- NAMA PRODUK -->
                      <?php 
                        if ($nm_produk == "") {
                      ?>
                          <td></td>
                      <?php
                        }else{
                      ?>
                          <td><?= $nm_produk; ?></td>
                      <?php
                        }
                      ?>

                      <!-- HARGA -->
                      <td id="bil1" name="bil1"><?= $harga_rupiah; ?></td>

                      <!-- HASIL -->
                      <td><?= $hasil_rupiah;?></td>

                      <td><button type="submit" name="" class="btn btn-danger">Cancel</button></td>

                  </tr>
                </tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
            
          </div>
          </form><!-- End General Form Elements -->
        </div>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>